const enum AppErrorCode {
    InvalidAccessToken = "InvalidAccessToken",
  }
  
  export default AppErrorCode;