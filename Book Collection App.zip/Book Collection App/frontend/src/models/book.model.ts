export interface Book {
    title: string;
    author: string;
    genre: string;
    publicationDate: string;
    _id: string
}